/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package epsi.lemans;
import epsi.lemans.User;
import epsi.lemans.service.UserFacadeREST;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.core.Context;
import javax.xml.bind.DatatypeConverter;

/**
 *
 * @author andré le paté
 * 
 * 
 * 
 */
@Stateless
public class AuthValidator {
    String salt = "proumizoulain";
    
    private EntityManager em1;
    
    public String sha1(String input) {
        String sha1 = null;
        try {
            MessageDigest msdDigest = MessageDigest.getInstance("SHA-1");
            msdDigest.update(input.getBytes("UTF-8"), 0, input.length());
            sha1 = DatatypeConverter.printHexBinary(msdDigest.digest());
        } catch (UnsupportedEncodingException | NoSuchAlgorithmException e) {
            //
        }
        return sha1;
    }
    
    public AuthValidator(){
        //em1 = Persistence.createEntityManagerFactory("ATCOVEA_RESTfulPU").createEntityManager();
    }
    
    public boolean AuthRequired(String _token){
        //  On retrouve le user grâce à son token
        //  Attention, le token peut alors être utilisé par une tierce personne...
        
        
        List<User> user_list = em1.createNamedQuery("User.findByToken").getResultList();
        User temp = user_list.get(0);
        if( temp == null){
            return false;
        }
        
        //  On compare avec _token
        //  
        if( _token.equals(temp.getToken()) ){
            return true;
        }
        else{
            return false;
        }
    }
    
    /*
    *   Le user enverra son user_id et son password
    *   Le token sera valide pour le user, et sa session_id uniquement,
    *       donc, cette donnée sera hashée avec le reste
    *   Token = sha1 ( user_id + password + session_id )
    *   Sinon, on renverra "null"
    */
    public String GenerateAuthToken(String _user_id, String _password){
        //  check if user exists
        //  then compare user pwd
        int user_id = Integer.parseInt(_user_id);
        
        System.err.println("pisse");
        //User pisse = (User)caca.getSingleResult();
        /*if(temp == null){
            return "null";
        }*/
        
        //  Il faudrait utiliser ici le même chiffrement que pour l'enregistrement du pwd
        /*String input_password_sha = sha1(_password);
        String stored_password_sha = temp.getPasswordUser();
        
        if( input_password_sha.equals(stored_password_sha) ){
            //  Si le pwd correspond, on génère le token
            String token = this.sha1( stored_password_sha );
            temp.setToken(token);
            em.close();
            return token;
        }
        else{
            em.close();
        }*/
        
        
        return "null";
    }
}
