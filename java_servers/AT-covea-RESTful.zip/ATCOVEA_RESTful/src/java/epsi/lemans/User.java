/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package epsi.lemans;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author andré le paté
 */
@Entity
@Table(name = "user")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "User.findAll", query = "SELECT u FROM User u")
    , @NamedQuery(name = "User.findByIdUser", query = "SELECT u FROM User u WHERE u.idUser = :idUser")
    , @NamedQuery(name = "User.findByIdentifiantUser", query = "SELECT u FROM User u WHERE u.identifiantUser = :identifiantUser")
    , @NamedQuery(name = "User.findByPasswordUser", query = "SELECT u FROM User u WHERE u.passwordUser = :passwordUser")
    , @NamedQuery(name = "User.findByToken", query = "SELECT u FROM User u WHERE u.token = :token")
})
public class User implements Serializable {

    @JoinColumn(name = "id_groupe_droit", referencedColumnName = "id_groupe_droit")
    @ManyToOne(optional = false)
    private GroupeDroit idGroupeDroit;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_user")
    private Integer idUser;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 25)
    @Column(name = "identifiant_user")
    private String identifiantUser;
    @Size(max = 25)
    @Column(name = "password_user")
    private String passwordUser;
    @Size(max = 60)
    @Column(name = "token")
    public String token;
    @JoinColumn(name = "id_droit", referencedColumnName = "id_droit")
    @ManyToOne(optional = false)
    private GroupeDroit idDroit;

    public User() {
        
    }

    public User(Integer idUser) {
        this.idUser = idUser;
    }

    public User(Integer idUser, String identifiantUser) {
        this.idUser = idUser;
        this.identifiantUser = identifiantUser;
    }

    public Integer getIdUser() {
        return idUser;
    }

    public void setIdUser(Integer idUser) {
        this.idUser = idUser;
    }

    public String getIdentifiantUser() {
        return identifiantUser;
    }

    public void setIdentifiantUser(String identifiantUser) {
        this.identifiantUser = identifiantUser;
    }

    public String getPasswordUser() {
        return passwordUser;
    }

    public void setPasswordUser(String passwordUser) {
        this.passwordUser = passwordUser;
    }

    public GroupeDroit getIdDroit() {
        return idDroit;
    }

    public void setIdDroit(GroupeDroit idDroit) {
        this.idDroit = idDroit;
    }
    
    public String getToken(){
        return token;
    }
    public void setToken(String _token){
        this.token = _token;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idUser != null ? idUser.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof User)) {
            return false;
        }
        User other = (User) object;
        if ((this.idUser == null && other.idUser != null) || (this.idUser != null && !this.idUser.equals(other.idUser))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "epsi.lemans.User[ idUser=" + idUser + " ]";
    }

    public GroupeDroit getIdGroupeDroit() {
        return idGroupeDroit;
    }

    public void setIdGroupeDroit(GroupeDroit idGroupeDroit) {
        this.idGroupeDroit = idGroupeDroit;
    }
    
}
