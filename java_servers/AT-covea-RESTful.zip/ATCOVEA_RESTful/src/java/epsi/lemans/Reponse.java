/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package epsi.lemans;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author andré le paté
 */
@Entity
@Table(name = "reponse")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Reponse.findAll", query = "SELECT r FROM Reponse r")
    , @NamedQuery(name = "Reponse.findByIdReponse", query = "SELECT r FROM Reponse r WHERE r.idReponse = :idReponse")
    , @NamedQuery(name = "Reponse.findBySousTraitantReponse", query = "SELECT r FROM Reponse r WHERE r.sousTraitantReponse = :sousTraitantReponse")
    , @NamedQuery(name = "Reponse.findByNbJours", query = "SELECT r FROM Reponse r WHERE r.nbJours = :nbJours")
    , @NamedQuery(name = "Reponse.findByTauxJournalier", query = "SELECT r FROM Reponse r WHERE r.tauxJournalier = :tauxJournalier")
    , @NamedQuery(name = "Reponse.findByDateDebut", query = "SELECT r FROM Reponse r WHERE r.dateDebut = :dateDebut")
    , @NamedQuery(name = "Reponse.findByDateFin", query = "SELECT r FROM Reponse r WHERE r.dateFin = :dateFin")})
public class Reponse implements Serializable {

    @JoinColumn(name = "id_interloc_technique_cgi", referencedColumnName = "id_interloc_technique_cgi")
    @ManyToOne(optional = false)
    private InterlocuteurTechniqueCgi idInterlocTechniqueCgi;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_reponse")
    private Integer idReponse;
    @Column(name = "sous_traitant_reponse")
    private Boolean sousTraitantReponse;
    @Column(name = "nb_jours")
    private Integer nbJours;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "taux_journalier")
    private Float tauxJournalier;
    @Column(name = "date_debut")
    @Temporal(TemporalType.DATE)
    private Date dateDebut;
    @Column(name = "date_fin")
    @Temporal(TemporalType.DATE)
    private Date dateFin;
    @ManyToMany(mappedBy = "reponseCollection")
    private Collection<Developpeur> developpeurCollection;
    @JoinColumn(name = "id_demande", referencedColumnName = "id_demande")
    @ManyToOne(optional = false)
    private Demande idDemande;

    public Reponse() {
    }

    public Reponse(Integer idReponse) {
        this.idReponse = idReponse;
    }

    public Integer getIdReponse() {
        return idReponse;
    }

    public void setIdReponse(Integer idReponse) {
        this.idReponse = idReponse;
    }

    public Boolean getSousTraitantReponse() {
        return sousTraitantReponse;
    }

    public void setSousTraitantReponse(Boolean sousTraitantReponse) {
        this.sousTraitantReponse = sousTraitantReponse;
    }

    public Integer getNbJours() {
        return nbJours;
    }

    public void setNbJours(Integer nbJours) {
        this.nbJours = nbJours;
    }

    public Float getTauxJournalier() {
        return tauxJournalier;
    }

    public void setTauxJournalier(Float tauxJournalier) {
        this.tauxJournalier = tauxJournalier;
    }

    public Date getDateDebut() {
        return dateDebut;
    }

    public void setDateDebut(Date dateDebut) {
        this.dateDebut = dateDebut;
    }

    public Date getDateFin() {
        return dateFin;
    }

    public void setDateFin(Date dateFin) {
        this.dateFin = dateFin;
    }

    @XmlTransient
    public Collection<Developpeur> getDeveloppeurCollection() {
        return developpeurCollection;
    }

    public void setDeveloppeurCollection(Collection<Developpeur> developpeurCollection) {
        this.developpeurCollection = developpeurCollection;
    }

    public Demande getIdDemande() {
        return idDemande;
    }

    public void setIdDemande(Demande idDemande) {
        this.idDemande = idDemande;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idReponse != null ? idReponse.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Reponse)) {
            return false;
        }
        Reponse other = (Reponse) object;
        if ((this.idReponse == null && other.idReponse != null) || (this.idReponse != null && !this.idReponse.equals(other.idReponse))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "epsi.lemans.Reponse[ idReponse=" + idReponse + " ]";
    }

    public InterlocuteurTechniqueCgi getIdInterlocTechniqueCgi() {
        return idInterlocTechniqueCgi;
    }

    public void setIdInterlocTechniqueCgi(InterlocuteurTechniqueCgi idInterlocTechniqueCgi) {
        this.idInterlocTechniqueCgi = idInterlocTechniqueCgi;
    }
    
}
