/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package epsi.lemans;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author andré le paté
 */
@Entity
@Table(name = "demande")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Demande.findAll", query = "SELECT d FROM Demande d")
    , @NamedQuery(name = "Demande.findByIdDemande", query = "SELECT d FROM Demande d WHERE d.idDemande = :idDemande")
    , @NamedQuery(name = "Demande.findByCodeAffaireDemande", query = "SELECT d FROM Demande d WHERE d.codeAffaireDemande = :codeAffaireDemande")
    , @NamedQuery(name = "Demande.findByLibelleDemande", query = "SELECT d FROM Demande d WHERE d.libelleDemande = :libelleDemande")
    , @NamedQuery(name = "Demande.findByDateDebutDemande", query = "SELECT d FROM Demande d WHERE d.dateDebutDemande = :dateDebutDemande")
    , @NamedQuery(name = "Demande.findByDateFinDemande", query = "SELECT d FROM Demande d WHERE d.dateFinDemande = :dateFinDemande")
    , @NamedQuery(name = "Demande.findByContexteDemande", query = "SELECT d FROM Demande d WHERE d.contexteDemande = :contexteDemande")
    , @NamedQuery(name = "Demande.findByDetailsPrestationDemande", query = "SELECT d FROM Demande d WHERE d.detailsPrestationDemande = :detailsPrestationDemande")
    , @NamedQuery(name = "Demande.findByStatutDemande", query = "SELECT d FROM Demande d WHERE d.statutDemande = :statutDemande")
    , @NamedQuery(name = "Demande.findByZoneGeographique", query = "SELECT d FROM Demande d WHERE d.zoneGeographique = :zoneGeographique")})
public class Demande implements Serializable {

    @Size(max = 30)
    @Column(name = "intitule_demande")
    private String intituleDemande;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_demande")
    private Integer idDemande;
    @Size(max = 9)
    @Column(name = "code_affaire_demande")
    private String codeAffaireDemande;
    @Size(max = 50)
    @Column(name = "libelle_demande")
    private String libelleDemande;
    @Column(name = "date_debut_demande")
    @Temporal(TemporalType.DATE)
    private Date dateDebutDemande;
    @Column(name = "date_fin_demande")
    @Temporal(TemporalType.DATE)
    private Date dateFinDemande;
    @Size(max = 150)
    @Column(name = "contexte_demande")
    private String contexteDemande;
    @Size(max = 300)
    @Column(name = "details_prestation_demande")
    private String detailsPrestationDemande;
    @Size(max = 25)
    @Column(name = "statut_demande")
    private String statutDemande;
    @Size(max = 25)
    @Column(name = "zone_geographique")
    private String zoneGeographique;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idDemande")
    private Collection<Reponse> reponseCollection;
    @JoinColumn(name = "id_acheteur", referencedColumnName = "id_acheteur")
    @ManyToOne(optional = false)
    private Acheteur idAcheteur;
    @JoinColumn(name = "id_interet", referencedColumnName = "id_interet")
    @ManyToOne(optional = false)
    private Interet idInteret;
    @JoinColumn(name = "id_interloc_technique", referencedColumnName = "id_interloc_technique")
    @ManyToOne(optional = false)
    private InterlocuteurTechnique idInterlocTechnique;
    @JoinColumn(name = "id_statut", referencedColumnName = "id_statut")
    @ManyToOne(optional = false)
    private Statut idStatut;

    public Demande() {
    }

    public Demande(Integer idDemande) {
        this.idDemande = idDemande;
    }

    public Integer getIdDemande() {
        return idDemande;
    }

    public void setIdDemande(Integer idDemande) {
        this.idDemande = idDemande;
    }

    public String getCodeAffaireDemande() {
        return codeAffaireDemande;
    }

    public void setCodeAffaireDemande(String codeAffaireDemande) {
        this.codeAffaireDemande = codeAffaireDemande;
    }

    public String getLibelleDemande() {
        return libelleDemande;
    }

    public void setLibelleDemande(String libelleDemande) {
        this.libelleDemande = libelleDemande;
    }

    public Date getDateDebutDemande() {
        return dateDebutDemande;
    }

    public void setDateDebutDemande(Date dateDebutDemande) {
        this.dateDebutDemande = dateDebutDemande;
    }

    public Date getDateFinDemande() {
        return dateFinDemande;
    }

    public void setDateFinDemande(Date dateFinDemande) {
        this.dateFinDemande = dateFinDemande;
    }

    public String getContexteDemande() {
        return contexteDemande;
    }

    public void setContexteDemande(String contexteDemande) {
        this.contexteDemande = contexteDemande;
    }

    public String getDetailsPrestationDemande() {
        return detailsPrestationDemande;
    }

    public void setDetailsPrestationDemande(String detailsPrestationDemande) {
        this.detailsPrestationDemande = detailsPrestationDemande;
    }

    public String getStatutDemande() {
        return statutDemande;
    }

    public void setStatutDemande(String statutDemande) {
        this.statutDemande = statutDemande;
    }

    public String getZoneGeographique() {
        return zoneGeographique;
    }

    public void setZoneGeographique(String zoneGeographique) {
        this.zoneGeographique = zoneGeographique;
    }

    @XmlTransient
    public Collection<Reponse> getReponseCollection() {
        return reponseCollection;
    }

    public void setReponseCollection(Collection<Reponse> reponseCollection) {
        this.reponseCollection = reponseCollection;
    }

    public Acheteur getIdAcheteur() {
        return idAcheteur;
    }

    public void setIdAcheteur(Acheteur idAcheteur) {
        this.idAcheteur = idAcheteur;
    }

    public Interet getIdInteret() {
        return idInteret;
    }

    public void setIdInteret(Interet idInteret) {
        this.idInteret = idInteret;
    }

    public InterlocuteurTechnique getIdInterlocTechnique() {
        return idInterlocTechnique;
    }

    public void setIdInterlocTechnique(InterlocuteurTechnique idInterlocTechnique) {
        this.idInterlocTechnique = idInterlocTechnique;
    }

    public Statut getIdStatut() {
        return idStatut;
    }

    public void setIdStatut(Statut idStatut) {
        this.idStatut = idStatut;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idDemande != null ? idDemande.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Demande)) {
            return false;
        }
        Demande other = (Demande) object;
        if ((this.idDemande == null && other.idDemande != null) || (this.idDemande != null && !this.idDemande.equals(other.idDemande))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "epsi.lemans.Demande[ idDemande=" + idDemande + " ]";
    }

    public String getIntituleDemande() {
        return intituleDemande;
    }

    public void setIntituleDemande(String intituleDemande) {
        this.intituleDemande = intituleDemande;
    }
    
}
