/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package epsi.lemans;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author andré le paté
 */
@Entity
@Table(name = "groupe_droit")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "GroupeDroit.findAll", query = "SELECT g FROM GroupeDroit g")
    , @NamedQuery(name = "GroupeDroit.findByIdDroit", query = "SELECT g FROM GroupeDroit g WHERE g.idDroit = :idDroit")
    , @NamedQuery(name = "GroupeDroit.findByNomGroupeDroit", query = "SELECT g FROM GroupeDroit g WHERE g.nomGroupeDroit = :nomGroupeDroit")
    , @NamedQuery(name = "GroupeDroit.findByCreer", query = "SELECT g FROM GroupeDroit g WHERE g.creer = :creer")
    , @NamedQuery(name = "GroupeDroit.findByEditer", query = "SELECT g FROM GroupeDroit g WHERE g.editer = :editer")
    , @NamedQuery(name = "GroupeDroit.findBySupprimer", query = "SELECT g FROM GroupeDroit g WHERE g.supprimer = :supprimer")
    , @NamedQuery(name = "GroupeDroit.findByRepondre", query = "SELECT g FROM GroupeDroit g WHERE g.repondre = :repondre")
    , @NamedQuery(name = "GroupeDroit.findByConsulter", query = "SELECT g FROM GroupeDroit g WHERE g.consulter = :consulter")})
public class GroupeDroit implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_groupe_droit")
    private Integer idGroupeDroit;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idGroupeDroit")
    private Collection<AttributionDroit> attributionDroitCollection;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_droit")
    private Integer idDroit;
    @Size(max = 25)
    @Column(name = "nom_groupe_droit")
    private String nomGroupeDroit;
    @Column(name = "creer")
    private Boolean creer;
    @Column(name = "editer")
    private Boolean editer;
    @Column(name = "supprimer")
    private Boolean supprimer;
    @Column(name = "repondre")
    private Boolean repondre;
    @Column(name = "consulter")
    private Boolean consulter;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idDroit")
    private Collection<User> userCollection;

    public GroupeDroit() {
    }

    public GroupeDroit(Integer idDroit) {
        this.idDroit = idDroit;
    }

    public Integer getIdDroit() {
        return idDroit;
    }

    public void setIdDroit(Integer idDroit) {
        this.idDroit = idDroit;
    }

    public String getNomGroupeDroit() {
        return nomGroupeDroit;
    }

    public void setNomGroupeDroit(String nomGroupeDroit) {
        this.nomGroupeDroit = nomGroupeDroit;
    }

    public Boolean getCreer() {
        return creer;
    }

    public void setCreer(Boolean creer) {
        this.creer = creer;
    }

    public Boolean getEditer() {
        return editer;
    }

    public void setEditer(Boolean editer) {
        this.editer = editer;
    }

    public Boolean getSupprimer() {
        return supprimer;
    }

    public void setSupprimer(Boolean supprimer) {
        this.supprimer = supprimer;
    }

    public Boolean getRepondre() {
        return repondre;
    }

    public void setRepondre(Boolean repondre) {
        this.repondre = repondre;
    }

    public Boolean getConsulter() {
        return consulter;
    }

    public void setConsulter(Boolean consulter) {
        this.consulter = consulter;
    }

    @XmlTransient
    public Collection<User> getUserCollection() {
        return userCollection;
    }

    public void setUserCollection(Collection<User> userCollection) {
        this.userCollection = userCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idDroit != null ? idDroit.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof GroupeDroit)) {
            return false;
        }
        GroupeDroit other = (GroupeDroit) object;
        if ((this.idDroit == null && other.idDroit != null) || (this.idDroit != null && !this.idDroit.equals(other.idDroit))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "epsi.lemans.GroupeDroit[ idDroit=" + idDroit + " ]";
    }


    public Integer getIdGroupeDroit() {
        return idGroupeDroit;
    }

    public void setIdGroupeDroit(Integer idGroupeDroit) {
        this.idGroupeDroit = idGroupeDroit;
    }

    @XmlTransient
    public Collection<AttributionDroit> getAttributionDroitCollection() {
        return attributionDroitCollection;
    }

    public void setAttributionDroitCollection(Collection<AttributionDroit> attributionDroitCollection) {
        this.attributionDroitCollection = attributionDroitCollection;
    }
    
}
