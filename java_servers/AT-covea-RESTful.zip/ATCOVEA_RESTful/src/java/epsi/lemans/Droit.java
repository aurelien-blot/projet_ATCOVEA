/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package epsi.lemans;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author andré le paté
 */
@Entity
@Table(name = "droit")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Droit.findAll", query = "SELECT d FROM Droit d")
    , @NamedQuery(name = "Droit.findByIdDroit", query = "SELECT d FROM Droit d WHERE d.idDroit = :idDroit")
    , @NamedQuery(name = "Droit.findByNomDroit", query = "SELECT d FROM Droit d WHERE d.nomDroit = :nomDroit")})
public class Droit implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_droit")
    private Integer idDroit;
    @Size(max = 25)
    @Column(name = "nom_droit")
    private String nomDroit;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idDroit")
    private Collection<AttributionDroit> attributionDroitCollection;

    public Droit() {
    }

    public Droit(Integer idDroit) {
        this.idDroit = idDroit;
    }

    public Integer getIdDroit() {
        return idDroit;
    }

    public void setIdDroit(Integer idDroit) {
        this.idDroit = idDroit;
    }

    public String getNomDroit() {
        return nomDroit;
    }

    public void setNomDroit(String nomDroit) {
        this.nomDroit = nomDroit;
    }

    @XmlTransient
    public Collection<AttributionDroit> getAttributionDroitCollection() {
        return attributionDroitCollection;
    }

    public void setAttributionDroitCollection(Collection<AttributionDroit> attributionDroitCollection) {
        this.attributionDroitCollection = attributionDroitCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idDroit != null ? idDroit.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Droit)) {
            return false;
        }
        Droit other = (Droit) object;
        if ((this.idDroit == null && other.idDroit != null) || (this.idDroit != null && !this.idDroit.equals(other.idDroit))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "epsi.lemans.Droit[ idDroit=" + idDroit + " ]";
    }
    
}
