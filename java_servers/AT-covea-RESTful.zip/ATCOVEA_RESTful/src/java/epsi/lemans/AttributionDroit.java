/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package epsi.lemans;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author andré le paté
 */
@Entity
@Table(name = "attribution_droit")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "AttributionDroit.findAll", query = "SELECT a FROM AttributionDroit a")
    , @NamedQuery(name = "AttributionDroit.findByIdAttribution", query = "SELECT a FROM AttributionDroit a WHERE a.idAttribution = :idAttribution")})
public class AttributionDroit implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_attribution")
    private Integer idAttribution;
    @JoinColumn(name = "id_droit", referencedColumnName = "id_droit")
    @ManyToOne(optional = false)
    private Droit idDroit;
    @JoinColumn(name = "id_groupe_droit", referencedColumnName = "id_groupe_droit")
    @ManyToOne(optional = false)
    private GroupeDroit idGroupeDroit;
    @JoinColumn(name = "id_nom_table", referencedColumnName = "id_nom_table")
    @ManyToOne(optional = false)
    private NomTable idNomTable;

    public AttributionDroit() {
    }

    public AttributionDroit(Integer idAttribution) {
        this.idAttribution = idAttribution;
    }

    public Integer getIdAttribution() {
        return idAttribution;
    }

    public void setIdAttribution(Integer idAttribution) {
        this.idAttribution = idAttribution;
    }

    public Droit getIdDroit() {
        return idDroit;
    }

    public void setIdDroit(Droit idDroit) {
        this.idDroit = idDroit;
    }

    public GroupeDroit getIdGroupeDroit() {
        return idGroupeDroit;
    }

    public void setIdGroupeDroit(GroupeDroit idGroupeDroit) {
        this.idGroupeDroit = idGroupeDroit;
    }

    public NomTable getIdNomTable() {
        return idNomTable;
    }

    public void setIdNomTable(NomTable idNomTable) {
        this.idNomTable = idNomTable;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idAttribution != null ? idAttribution.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof AttributionDroit)) {
            return false;
        }
        AttributionDroit other = (AttributionDroit) object;
        if ((this.idAttribution == null && other.idAttribution != null) || (this.idAttribution != null && !this.idAttribution.equals(other.idAttribution))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "epsi.lemans.AttributionDroit[ idAttribution=" + idAttribution + " ]";
    }
    
}
