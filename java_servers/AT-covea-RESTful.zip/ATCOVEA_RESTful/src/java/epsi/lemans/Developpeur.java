/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package epsi.lemans;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author andré le paté
 */
@Entity
@Table(name = "developpeur")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Developpeur.findAll", query = "SELECT d FROM Developpeur d")
    , @NamedQuery(name = "Developpeur.findByIdDeveloppeur", query = "SELECT d FROM Developpeur d WHERE d.idDeveloppeur = :idDeveloppeur")
    , @NamedQuery(name = "Developpeur.findByNomDeveloppeur", query = "SELECT d FROM Developpeur d WHERE d.nomDeveloppeur = :nomDeveloppeur")
    , @NamedQuery(name = "Developpeur.findByPrenomDeveloppeur", query = "SELECT d FROM Developpeur d WHERE d.prenomDeveloppeur = :prenomDeveloppeur")
    , @NamedQuery(name = "Developpeur.findByCompetencesDeveloppeur", query = "SELECT d FROM Developpeur d WHERE d.competencesDeveloppeur = :competencesDeveloppeur")
    , @NamedQuery(name = "Developpeur.findByCv", query = "SELECT d FROM Developpeur d WHERE d.cv = :cv")})
public class Developpeur implements Serializable {

    @Size(max = 100)
    @Column(name = "mail_developpeur")
    private String mailDeveloppeur;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_developpeur")
    private Integer idDeveloppeur;
    @Size(max = 25)
    @Column(name = "nom_developpeur")
    private String nomDeveloppeur;
    @Size(max = 25)
    @Column(name = "prenom_developpeur")
    private String prenomDeveloppeur;
    @Size(max = 300)
    @Column(name = "competences_developpeur")
    private String competencesDeveloppeur;
    @Size(max = 100)
    @Column(name = "cv")
    private String cv;
    @JoinTable(name = "retenir", joinColumns = {
        @JoinColumn(name = "id_developpeur", referencedColumnName = "id_developpeur")}, inverseJoinColumns = {
        @JoinColumn(name = "id_reponse", referencedColumnName = "id_reponse")})
    @ManyToMany
    private Collection<Reponse> reponseCollection;

    public Developpeur() {
    }

    public Developpeur(Integer idDeveloppeur) {
        this.idDeveloppeur = idDeveloppeur;
    }

    public Integer getIdDeveloppeur() {
        return idDeveloppeur;
    }

    public void setIdDeveloppeur(Integer idDeveloppeur) {
        this.idDeveloppeur = idDeveloppeur;
    }

    public String getNomDeveloppeur() {
        return nomDeveloppeur;
    }

    public void setNomDeveloppeur(String nomDeveloppeur) {
        this.nomDeveloppeur = nomDeveloppeur;
    }

    public String getPrenomDeveloppeur() {
        return prenomDeveloppeur;
    }

    public void setPrenomDeveloppeur(String prenomDeveloppeur) {
        this.prenomDeveloppeur = prenomDeveloppeur;
    }

    public String getCompetencesDeveloppeur() {
        return competencesDeveloppeur;
    }

    public void setCompetencesDeveloppeur(String competencesDeveloppeur) {
        this.competencesDeveloppeur = competencesDeveloppeur;
    }

    public String getCv() {
        return cv;
    }

    public void setCv(String cv) {
        this.cv = cv;
    }

    @XmlTransient
    public Collection<Reponse> getReponseCollection() {
        return reponseCollection;
    }

    public void setReponseCollection(Collection<Reponse> reponseCollection) {
        this.reponseCollection = reponseCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idDeveloppeur != null ? idDeveloppeur.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Developpeur)) {
            return false;
        }
        Developpeur other = (Developpeur) object;
        if ((this.idDeveloppeur == null && other.idDeveloppeur != null) || (this.idDeveloppeur != null && !this.idDeveloppeur.equals(other.idDeveloppeur))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "epsi.lemans.Developpeur[ idDeveloppeur=" + idDeveloppeur + " ]";
    }

    public String getMailDeveloppeur() {
        return mailDeveloppeur;
    }

    public void setMailDeveloppeur(String mailDeveloppeur) {
        this.mailDeveloppeur = mailDeveloppeur;
    }
    
}
