/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package epsi.lemans;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author andré le paté
 */
@Entity
@Table(name = "acheteur")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Acheteur.findAll", query = "SELECT a FROM Acheteur a")
    , @NamedQuery(name = "Acheteur.findByIdAcheteur", query = "SELECT a FROM Acheteur a WHERE a.idAcheteur = :idAcheteur")
    , @NamedQuery(name = "Acheteur.findByNomAcheteur", query = "SELECT a FROM Acheteur a WHERE a.nomAcheteur = :nomAcheteur")
    , @NamedQuery(name = "Acheteur.findByPrenomAcheteur", query = "SELECT a FROM Acheteur a WHERE a.prenomAcheteur = :prenomAcheteur")})
public class Acheteur implements Serializable {

    @Size(max = 100)
    @Column(name = "mail_acheteur")
    private String mailAcheteur;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_acheteur")
    private Integer idAcheteur;
    @Size(max = 25)
    @Column(name = "nom_acheteur")
    private String nomAcheteur;
    @Size(max = 25)
    @Column(name = "prenom_acheteur")
    private String prenomAcheteur;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idAcheteur")
    private Collection<Demande> demandeCollection;

    public Acheteur() {
    }

    public Acheteur(Integer idAcheteur) {
        this.idAcheteur = idAcheteur;
    }

    public Integer getIdAcheteur() {
        return idAcheteur;
    }

    public void setIdAcheteur(Integer idAcheteur) {
        this.idAcheteur = idAcheteur;
    }

    public String getNomAcheteur() {
        return nomAcheteur;
    }

    public void setNomAcheteur(String nomAcheteur) {
        this.nomAcheteur = nomAcheteur;
    }

    public String getPrenomAcheteur() {
        return prenomAcheteur;
    }

    public void setPrenomAcheteur(String prenomAcheteur) {
        this.prenomAcheteur = prenomAcheteur;
    }

    @XmlTransient
    public Collection<Demande> getDemandeCollection() {
        return demandeCollection;
    }

    public void setDemandeCollection(Collection<Demande> demandeCollection) {
        this.demandeCollection = demandeCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idAcheteur != null ? idAcheteur.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Acheteur)) {
            return false;
        }
        Acheteur other = (Acheteur) object;
        if ((this.idAcheteur == null && other.idAcheteur != null) || (this.idAcheteur != null && !this.idAcheteur.equals(other.idAcheteur))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "epsi.lemans.Acheteur[ idAcheteur=" + idAcheteur + " ]";
    }

    public String getMailAcheteur() {
        return mailAcheteur;
    }

    public void setMailAcheteur(String mailAcheteur) {
        this.mailAcheteur = mailAcheteur;
    }
    
}
