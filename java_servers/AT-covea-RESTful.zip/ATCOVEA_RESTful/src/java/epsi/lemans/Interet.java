/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package epsi.lemans;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author andré le paté
 */
@Entity
@Table(name = "interet")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Interet.findAll", query = "SELECT i FROM Interet i")
    , @NamedQuery(name = "Interet.findByIdInteret", query = "SELECT i FROM Interet i WHERE i.idInteret = :idInteret")
    , @NamedQuery(name = "Interet.findByLibelleInteret", query = "SELECT i FROM Interet i WHERE i.libelleInteret = :libelleInteret")})
public class Interet implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_interet")
    private Integer idInteret;
    @Size(max = 25)
    @Column(name = "libelle_interet")
    private String libelleInteret;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idInteret")
    private Collection<Demande> demandeCollection;

    public Interet() {
    }

    public Interet(Integer idInteret) {
        this.idInteret = idInteret;
    }

    public Integer getIdInteret() {
        return idInteret;
    }

    public void setIdInteret(Integer idInteret) {
        this.idInteret = idInteret;
    }

    public String getLibelleInteret() {
        return libelleInteret;
    }

    public void setLibelleInteret(String libelleInteret) {
        this.libelleInteret = libelleInteret;
    }

    @XmlTransient
    public Collection<Demande> getDemandeCollection() {
        return demandeCollection;
    }

    public void setDemandeCollection(Collection<Demande> demandeCollection) {
        this.demandeCollection = demandeCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idInteret != null ? idInteret.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Interet)) {
            return false;
        }
        Interet other = (Interet) object;
        if ((this.idInteret == null && other.idInteret != null) || (this.idInteret != null && !this.idInteret.equals(other.idInteret))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "epsi.lemans.Interet[ idInteret=" + idInteret + " ]";
    }
    
}
