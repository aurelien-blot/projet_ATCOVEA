/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package epsi.lemans;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author andré le paté
 */
@Entity
@Table(name = "interlocuteur_technique")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "InterlocuteurTechnique.findAll", query = "SELECT i FROM InterlocuteurTechnique i")
    , @NamedQuery(name = "InterlocuteurTechnique.findByIdInterlocTechnique", query = "SELECT i FROM InterlocuteurTechnique i WHERE i.idInterlocTechnique = :idInterlocTechnique")
    , @NamedQuery(name = "InterlocuteurTechnique.findByNomInterlocTechnique", query = "SELECT i FROM InterlocuteurTechnique i WHERE i.nomInterlocTechnique = :nomInterlocTechnique")
    , @NamedQuery(name = "InterlocuteurTechnique.findByPrenomInterlocTechnique", query = "SELECT i FROM InterlocuteurTechnique i WHERE i.prenomInterlocTechnique = :prenomInterlocTechnique")
    , @NamedQuery(name = "InterlocuteurTechnique.findByMailInterlocTechnique", query = "SELECT i FROM InterlocuteurTechnique i WHERE i.mailInterlocTechnique = :mailInterlocTechnique")
    , @NamedQuery(name = "InterlocuteurTechnique.findByTelInterlocTechnique", query = "SELECT i FROM InterlocuteurTechnique i WHERE i.telInterlocTechnique = :telInterlocTechnique")})
public class InterlocuteurTechnique implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_interloc_technique")
    private Integer idInterlocTechnique;
    @Size(max = 25)
    @Column(name = "nom_interloc_technique")
    private String nomInterlocTechnique;
    @Size(max = 25)
    @Column(name = "prenom_interloc_technique")
    private String prenomInterlocTechnique;
    @Size(max = 100)
    @Column(name = "mail_interloc_technique")
    private String mailInterlocTechnique;
    @Size(max = 25)
    @Column(name = "tel_interloc_technique")
    private String telInterlocTechnique;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idInterlocTechnique")
    private Collection<Demande> demandeCollection;

    public InterlocuteurTechnique() {
    }

    public InterlocuteurTechnique(Integer idInterlocTechnique) {
        this.idInterlocTechnique = idInterlocTechnique;
    }

    public Integer getIdInterlocTechnique() {
        return idInterlocTechnique;
    }

    public void setIdInterlocTechnique(Integer idInterlocTechnique) {
        this.idInterlocTechnique = idInterlocTechnique;
    }

    public String getNomInterlocTechnique() {
        return nomInterlocTechnique;
    }

    public void setNomInterlocTechnique(String nomInterlocTechnique) {
        this.nomInterlocTechnique = nomInterlocTechnique;
    }

    public String getPrenomInterlocTechnique() {
        return prenomInterlocTechnique;
    }

    public void setPrenomInterlocTechnique(String prenomInterlocTechnique) {
        this.prenomInterlocTechnique = prenomInterlocTechnique;
    }

    public String getMailInterlocTechnique() {
        return mailInterlocTechnique;
    }

    public void setMailInterlocTechnique(String mailInterlocTechnique) {
        this.mailInterlocTechnique = mailInterlocTechnique;
    }

    public String getTelInterlocTechnique() {
        return telInterlocTechnique;
    }

    public void setTelInterlocTechnique(String telInterlocTechnique) {
        this.telInterlocTechnique = telInterlocTechnique;
    }

    @XmlTransient
    public Collection<Demande> getDemandeCollection() {
        return demandeCollection;
    }

    public void setDemandeCollection(Collection<Demande> demandeCollection) {
        this.demandeCollection = demandeCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idInterlocTechnique != null ? idInterlocTechnique.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof InterlocuteurTechnique)) {
            return false;
        }
        InterlocuteurTechnique other = (InterlocuteurTechnique) object;
        if ((this.idInterlocTechnique == null && other.idInterlocTechnique != null) || (this.idInterlocTechnique != null && !this.idInterlocTechnique.equals(other.idInterlocTechnique))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "epsi.lemans.InterlocuteurTechnique[ idInterlocTechnique=" + idInterlocTechnique + " ]";
    }
    
}
