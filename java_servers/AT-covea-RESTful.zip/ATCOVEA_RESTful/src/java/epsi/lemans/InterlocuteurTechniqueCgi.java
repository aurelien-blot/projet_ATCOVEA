/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package epsi.lemans;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author andré le paté
 */
@Entity
@Table(name = "interlocuteur_technique_cgi")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "InterlocuteurTechniqueCgi.findAll", query = "SELECT i FROM InterlocuteurTechniqueCgi i")
    , @NamedQuery(name = "InterlocuteurTechniqueCgi.findByIdInterlocTechniqueCgi", query = "SELECT i FROM InterlocuteurTechniqueCgi i WHERE i.idInterlocTechniqueCgi = :idInterlocTechniqueCgi")
    , @NamedQuery(name = "InterlocuteurTechniqueCgi.findByNomInterlocTechniqueCgi", query = "SELECT i FROM InterlocuteurTechniqueCgi i WHERE i.nomInterlocTechniqueCgi = :nomInterlocTechniqueCgi")
    , @NamedQuery(name = "InterlocuteurTechniqueCgi.findByPrenomInterlocTechniqueCgi", query = "SELECT i FROM InterlocuteurTechniqueCgi i WHERE i.prenomInterlocTechniqueCgi = :prenomInterlocTechniqueCgi")
    , @NamedQuery(name = "InterlocuteurTechniqueCgi.findByMailInterlocTechniqueCgi", query = "SELECT i FROM InterlocuteurTechniqueCgi i WHERE i.mailInterlocTechniqueCgi = :mailInterlocTechniqueCgi")
    , @NamedQuery(name = "InterlocuteurTechniqueCgi.findByTelInterlocTechniqueCgi", query = "SELECT i FROM InterlocuteurTechniqueCgi i WHERE i.telInterlocTechniqueCgi = :telInterlocTechniqueCgi")})
public class InterlocuteurTechniqueCgi implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_interloc_technique_cgi")
    private Integer idInterlocTechniqueCgi;
    @Size(max = 25)
    @Column(name = "nom_interloc_technique_cgi")
    private String nomInterlocTechniqueCgi;
    @Size(max = 25)
    @Column(name = "prenom_interloc_technique_cgi")
    private String prenomInterlocTechniqueCgi;
    @Size(max = 100)
    @Column(name = "mail_interloc_technique_cgi")
    private String mailInterlocTechniqueCgi;
    @Size(max = 25)
    @Column(name = "tel_interloc_technique_cgi")
    private String telInterlocTechniqueCgi;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idInterlocTechniqueCgi")
    private Collection<Reponse> reponseCollection;

    public InterlocuteurTechniqueCgi() {
    }

    public InterlocuteurTechniqueCgi(Integer idInterlocTechniqueCgi) {
        this.idInterlocTechniqueCgi = idInterlocTechniqueCgi;
    }

    public Integer getIdInterlocTechniqueCgi() {
        return idInterlocTechniqueCgi;
    }

    public void setIdInterlocTechniqueCgi(Integer idInterlocTechniqueCgi) {
        this.idInterlocTechniqueCgi = idInterlocTechniqueCgi;
    }

    public String getNomInterlocTechniqueCgi() {
        return nomInterlocTechniqueCgi;
    }

    public void setNomInterlocTechniqueCgi(String nomInterlocTechniqueCgi) {
        this.nomInterlocTechniqueCgi = nomInterlocTechniqueCgi;
    }

    public String getPrenomInterlocTechniqueCgi() {
        return prenomInterlocTechniqueCgi;
    }

    public void setPrenomInterlocTechniqueCgi(String prenomInterlocTechniqueCgi) {
        this.prenomInterlocTechniqueCgi = prenomInterlocTechniqueCgi;
    }

    public String getMailInterlocTechniqueCgi() {
        return mailInterlocTechniqueCgi;
    }

    public void setMailInterlocTechniqueCgi(String mailInterlocTechniqueCgi) {
        this.mailInterlocTechniqueCgi = mailInterlocTechniqueCgi;
    }

    public String getTelInterlocTechniqueCgi() {
        return telInterlocTechniqueCgi;
    }

    public void setTelInterlocTechniqueCgi(String telInterlocTechniqueCgi) {
        this.telInterlocTechniqueCgi = telInterlocTechniqueCgi;
    }

    @XmlTransient
    public Collection<Reponse> getReponseCollection() {
        return reponseCollection;
    }

    public void setReponseCollection(Collection<Reponse> reponseCollection) {
        this.reponseCollection = reponseCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idInterlocTechniqueCgi != null ? idInterlocTechniqueCgi.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof InterlocuteurTechniqueCgi)) {
            return false;
        }
        InterlocuteurTechniqueCgi other = (InterlocuteurTechniqueCgi) object;
        if ((this.idInterlocTechniqueCgi == null && other.idInterlocTechniqueCgi != null) || (this.idInterlocTechniqueCgi != null && !this.idInterlocTechniqueCgi.equals(other.idInterlocTechniqueCgi))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "epsi.lemans.InterlocuteurTechniqueCgi[ idInterlocTechniqueCgi=" + idInterlocTechniqueCgi + " ]";
    }
    
}
