/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package epsi.lemans;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author andré le paté
 */
@Entity
@Table(name = "nom_table")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "NomTable.findAll", query = "SELECT n FROM NomTable n")
    , @NamedQuery(name = "NomTable.findByIdNomTable", query = "SELECT n FROM NomTable n WHERE n.idNomTable = :idNomTable")
    , @NamedQuery(name = "NomTable.findByNomTable", query = "SELECT n FROM NomTable n WHERE n.nomTable = :nomTable")})
public class NomTable implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_nom_table")
    private Integer idNomTable;
    @Size(max = 60)
    @Column(name = "nom_table")
    private String nomTable;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idNomTable")
    private Collection<AttributionDroit> attributionDroitCollection;

    public NomTable() {
    }

    public NomTable(Integer idNomTable) {
        this.idNomTable = idNomTable;
    }

    public Integer getIdNomTable() {
        return idNomTable;
    }

    public void setIdNomTable(Integer idNomTable) {
        this.idNomTable = idNomTable;
    }

    public String getNomTable() {
        return nomTable;
    }

    public void setNomTable(String nomTable) {
        this.nomTable = nomTable;
    }

    @XmlTransient
    public Collection<AttributionDroit> getAttributionDroitCollection() {
        return attributionDroitCollection;
    }

    public void setAttributionDroitCollection(Collection<AttributionDroit> attributionDroitCollection) {
        this.attributionDroitCollection = attributionDroitCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idNomTable != null ? idNomTable.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof NomTable)) {
            return false;
        }
        NomTable other = (NomTable) object;
        if ((this.idNomTable == null && other.idNomTable != null) || (this.idNomTable != null && !this.idNomTable.equals(other.idNomTable))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "epsi.lemans.NomTable[ idNomTable=" + idNomTable + " ]";
    }
    
}
