/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package epsi.lemans.service;

import java.util.Set;
import javax.ws.rs.core.Application;

/**
 *
 * @author andré le paté
 */
@javax.ws.rs.ApplicationPath("webresources")
public class ApplicationConfig extends Application {

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new java.util.HashSet<>();
        addRestResourceClasses(resources);
        return resources;
    }

    /**
     * Do not modify addRestResourceClasses() method.
     * It is automatically populated with
     * all resources defined in the project.
     * If required, comment out calling this method in getClasses().
     */
    private void addRestResourceClasses(Set<Class<?>> resources) {
        resources.add(epsi.lemans.filter.NewCrossOriginResourceSharingFilter.class);
        resources.add(epsi.lemans.service.AcheteurFacadeREST.class);
        resources.add(epsi.lemans.service.AttributionDroitFacadeREST.class);
        resources.add(epsi.lemans.service.DemandeFacadeREST.class);
        resources.add(epsi.lemans.service.DeveloppeurFacadeREST.class);
        resources.add(epsi.lemans.service.DroitFacadeREST.class);
        resources.add(epsi.lemans.service.GroupeDroitFacadeREST.class);
        resources.add(epsi.lemans.service.InteretFacadeREST.class);
        resources.add(epsi.lemans.service.InterlocuteurTechniqueCgiFacadeREST.class);
        resources.add(epsi.lemans.service.InterlocuteurTechniqueFacadeREST.class);
        resources.add(epsi.lemans.service.NomTableFacadeREST.class);
        resources.add(epsi.lemans.service.ReponseFacadeREST.class);
        resources.add(epsi.lemans.service.StatutFacadeREST.class);
        resources.add(epsi.lemans.service.UserFacadeREST.class);
    }
    
}
